if(language=="en"){
  var name = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  var windtxt = "Wind: ";
  var feeltxt = "Feels Like: ";
  var sunrisetxt = "Sunrise: ";
  var sunsettxt = "Sunset: ";
  var textstringlater="Later Today: ";
  var humidtxt="Humidity: ";
  var warningtxt = "Warning: ";
  var preciptxt = "Precip ";
  }
  else if(language=="it"){
  var name = ['Domenica','Luned&#236','Marted&#236','Mercoled&#236','Gioved&#236','Venerd&#236','Sabato'];
  var month=["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];
  var smonth=["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"];
  var sday=["Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat"];
  var windtxt = "Vento: ";
  var feeltxt = "Sembra: ";
  var sunrisetxt = "Alba: ";
  var sunsettxt = "Tramonto: ";
  var textstringlater="Più tardi oggi: ";
  var humidtxt="Umidità: ";
  var warningtxt = "Avvertimento: ";
  var preciptxt = "Pioggia ";
  }
  else if(language=="sp"){
  var name = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
  var month=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
  var smonth=["Ene","Feb","Mar","Abr","Mayo","Jun","Jul","Aug","Sep","Oct","Nov","Dic"];
  var sday=["Sol","Mon","Mar","Mie","Jue","Vie","Sat"];
  var windtxt = "Viento: ";
  var feeltxt = "Sensación térmica: ";
  var sunrisetxt = "Salida del sol: ";
  var sunsettxt = "Puesta del sol: ";
  var textstringlater="Para hoy más tarde: ";
  var humidtxt="Humedad: ";
  var warningtxt = "Advertencia: ";
  var preciptxt = "Precip ";

  }
  else if(language=="de"){
  var name = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  var month=["Januari","Februari","Maart","April","Kunnen","Juni","Juli","Augustus","September","Oktober","November","Dezember"];
  var smonth=["Jan", "Feb", "Maa", "Apr", "Kun", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "];
  var sday=["Son","Mon","Die","Mit","Don","Fre","Sam"];
  var windtxt = "Wind: ";
  var feeltxt = "Voelt aan als: ";
  var sunrisetxt = "Zonsopgang: ";
  var sunsettxt = "Zonsondergang: ";
  var textstringlater="Later Vandaag: ";
  var humidtxt="Vochtigheid: ";
  var warningtxt = "Waarschuwing: ";
  var preciptxt = "Neerslag ";
  }
  else if(language=="fr"){
  var name = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  var month=["Janvie","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
  var smonth=["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"];
  var sday=["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
  var windtxt = "Vent: ";
  var feeltxt = "Ressenti: ";
  var sunrisetxt = "Lever du soleil: ";
  var sunsettxt = "Coucher du soleil: ";
  var textstringlater="Plus tard aujourd'hui: ";
  var humidtxt="Humidité: ";
  var warningtxt = "Avertissement: ";
  var preciptxt = "Précipitations: ";
  }
  else if(language=="zh"){
    var name = ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'];
    var month=['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var smonth=['一','二','三','四','五','六','七','八','九','十','十一','十二'];
    var sday=['周日','周一','周二','周三','周四','周五','周六'];
    var windtxt = "风: ";
    var feeltxt = "感觉好像: ";
    var sunrisetxt = "日出: ";
    var sunsettxt = "日落: ";
    var textstringlater="今天晚些时候: ";
    var humidtxt="湿度: ";
    var warningtxt = "警告: ";
    var preciptxt = "雨 ";
  }
  else if(language=="vi"){
  var name = ["Chủ Nhật","Thứ Hai","Thứ Ba","Thứ Tư","Thứ Năm","Thứ Sáu","Thứ Bảy"];
  var month=["Tháng 1","Tháng 2","Tháng 3","Tháng 4","Tháng 5","Tháng 6","Tháng 7","Tháng 8","Tháng 9","Tháng 10","Tháng 11","Tháng 12"];
  var smonth=["Thg 1","Thg 2","Thg 3","Thg 4","Thg 5","Thg 6","Thg 7","Thg 8","Thg 9","Thg 10","Thg 11","Thg 12"];
  var sday=["CN","Th2","Th3","Th4","Th5","Th6","Th7"];
  var windtxt = "Gió: ";
  var feeltxt = "Cảm Giác Như: ";
  var sunrisetxt = "Mặt Trời Mọc: ";
  var sunsettxt = "Mặt Trời Lặn: ";
  var textstringlater="Sau Hôm Nay: ";
  var humidtxt="Độ Ẩm: ";
  var warningtxt = "Cảnh Báo: ";
  var preciptxt = "Lượng Mưa ";
  }
  else{
  var name = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  var windtxt = "Wind: ";
  var feeltxt = "Feels Like: ";
  var sunrisetxt = "Sunrise: ";
  var sunsettxt = "Sunset: ";
  var textstringlater="Later Today:";
  var humidtxt="Humidity: ";
  var warningtxt = "Warning: ";
  var preciptxt = "Precip ";
  }