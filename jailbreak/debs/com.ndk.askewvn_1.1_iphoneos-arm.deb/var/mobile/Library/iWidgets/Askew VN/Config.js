var Scale = "1"; // Kích thước tuỳ chỉnh
var Clock = "24h"; // Đồng hồ "12h" và "24h"
var refreshrate = 10; // Thời gian cập nhật thời tiết
var TextColor1 = "#fff"; // Màu chữ chào ngày mới và đồng hồ
var TextColor2 = "#fff"; // Màu chữ thời thiết 
var BlurBackground = false; // Nền mờ
var HideBackground = true; // Ẩn nền
var BackgroundColor = "red"; // Nền tuỳ chọn
