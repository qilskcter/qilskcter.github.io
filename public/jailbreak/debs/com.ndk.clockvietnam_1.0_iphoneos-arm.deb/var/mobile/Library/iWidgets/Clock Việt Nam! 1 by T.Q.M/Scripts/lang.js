var twentyfourhour = true; // 
var pad = true; // 
var Clock = "24h"; //

var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        vi: {
            weekday: ["C.N","T.2","T.3","T.4","T.5","T.6","T.7"],
            sday: ["C.N","T.2","T.3","T.4","T.5","T.6","T.7"],
            month: ["1","2","3","4","5","6","7","8","9","10","11","12"],
            smonth: ["1","2","3","4","5","6","7","8","9","10","11","12"]
        },
        en: {
            weekday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            sday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            month: ["1","2","3","4","5","6","7","8","9","10","11","12"],
            smonth: ["1","2","3","4","5","6","7","8","9","10","11","12"]
        }
    };
if (!translate[current]) {
    current = 'en';
}
