var textcolor = "red"; // Màu Lịch
var scle = 0.6; // Tuỳ chỉnh kích cỡ
var Wallpaper = "1"; // 1 - 2 ( Mặt Đồng hồ )
var Layer = "1"; // 1 - 2 ( Nền Ngày )
var NoWatchS6 = "1"; // 1 - 6 ( Khung không dây S6 ) , ( Đưa về 0 để thay khung khác )
var NoWatchS1 = "0"; // 1 - 9 ( Khung không dây S1 ) , ( Đưa về 0 để thay khung khác )
var AppleWatchS1 = "0"; // 1 - 12 ( Khung có dây S1 ), ( Đưa về 0 để thay khung khác )
var AppleWatchS6 = "0"; // 1 - 6 ( Khung có dây S6 ) , ( Đưa về 0 để thay khung khác )
