I'm working on localization, if you like my tweak and want to help, you can help me translate to your language.

(Finished languages are here: https://github.com/haoict/redditnoads/tree/master/pref/Resources)

Here are base strings

```
"DO_YOU_REALLY_WANT_TO_KILL_REDDIT" = "Do you really want to kill Reddit?";
"REMOVE_ADS_IN_NEWS_FEED" = "Remove Ads in News Feed";
```

After you finished translation, Please save and name it with your language code (if you don't know, just write down your country name)

E.g: English -> en, Japanese -> ja, Vietnamese -> vi...

And your nick name, I will add to Contributors part.

Finally, send me the result to my email "hao.ict56@gmail.com" or open issue on github.
