if (Lang = "vi") {
var shortdays = ["CN", "Th2", "Th3", "Th4", "Th5", "Th6", "Th7"];
var shortmonths = ["Thg 1", "Thg 2", "Thg 3", "Thg 4", "Thg 5", "Thg 6", "Thg 7", "Thg 8", "Thg 9", "Thg 10", "Thg 11", "Thg 12"];}