window.addEventListener("load", function() {
}, false);
function init(){
if(ba === 1){
updateClock();
setInterval("updateClock();", 1000);}
checkSettings();}
function checkSettings(){
document.documentElement.style.setProperty('--br', br + 'px');
document.documentElement.style.setProperty('--bl', bl + 'px');
document.documentElement.style.setProperty('--primary', C1);
document.documentElement.style.setProperty('--secondary', C2);
document.documentElement.style.setProperty('--third', C3);
document.documentElement.style.setProperty('--primaryB', C4);
if(ba === 0){
document.getElementById('mainCont').style.display = 'none';}
document.documentElement.style.setProperty('--cW', cW + 'px');
document.documentElement.style.setProperty('--cH', cH + 'px');
document.documentElement.style.setProperty('--cY', cY + 'px');
document.documentElement.style.setProperty('--cX', cX + '%');
if(mu === 0){
document.getElementById('musCont').style.display = 'none';}
document.documentElement.style.setProperty('--mW', mW + '%');
if(mb === 1){
document.getElementById("musCont").classList.add('bottom');
document.getElementById("sepCont").classList.add('top');
document.getElementById("minTitle").classList.add('top');
if(dock === 0){
document.documentElement.style.setProperty('--mcY', '50%');
}else{
document.documentElement.style.setProperty('--mcY', '60px');
document.documentElement.style.setProperty('--mH', mH + 'px');
document.documentElement.style.setProperty('--bSpace', bs + 'px');}
}else{
document.getElementById("musCont").classList.add('top');
document.getElementById("sepCont").classList.add('bottom');
document.getElementById("minTitle").classList.add('bottom');}}
function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes();
var currentMinutes1 = currentTime.getMinutes();
var currentMinutesunit = currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
if(Time24 === 1){
Clock = "24h";
}else{
Clock = "12h";}
if (Clock === "24h"){
currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;}
if (Clock === "12h"){
currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
currentHours = ( currentHours == 0 ) ? 12 : currentHours;
currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;}
document.getElementById("time").innerHTML = currentHours + ':' + currentMinutes1;
document.getElementById("day").innerHTML = shortdays[currentTime.getDay()];
document.getElementById("date").innerHTML = currentDate;
document.getElementById("month").innerHTML = shortmonths[currentTime.getMonth()];}
function openMu(){
if(document.getElementById("musCont").classList.contains('closed')){
document.getElementById("musCont").classList.remove('closed');
document.getElementById("musCont").classList.add('open');
if(document.getElementById("musCont").classList.contains('top')){
document.getElementById("musCont").classList.remove('movetop');}
if(document.getElementById("musCont").classList.contains('bottom')){
document.getElementById("musCont").classList.remove('movebottom');}
document.getElementById("infoCont").classList.remove('move');
document.getElementById("btnCont").classList.remove('move');
document.getElementById("playPause").classList.remove('move');
document.getElementById('minTitle').style.opacity = 0;
return;
}else{
document.getElementById("musCont").classList.add('closed');
document.getElementById("musCont").classList.remove('open');
if(document.getElementById("musCont").classList.contains('top')){
document.getElementById("musCont").classList.add('movetop');}if(document.getElementById("musCont").classList.contains('bottom')){
document.getElementById("musCont").classList.add('movebottom');}
document.getElementById("infoCont").classList.add('move');
document.getElementById("btnCont").classList.add('move');
document.getElementById("playPause").classList.add('move');
document.getElementById('minTitle').style.opacity = 0.5;
return;}}
function moveInfo(){if(
document.getElementById("mainCont").classList.contains('open')){
document.getElementById("mainCont").classList.remove('open');
document.getElementById("mainCont").classList.add('closed');
document.getElementById("timeCont").classList.add('closed');
document.getElementById("signalCont").classList.add('closed');
return;
}else{
document.getElementById("mainCont").classList.add('open');
document.getElementById("mainCont").classList.remove('closed');
setTimeout(function (){
document.getElementById("timeCont").classList.remove('closed');
document.getElementById("signalCont").classList.remove('closed');}, 500);return;}}