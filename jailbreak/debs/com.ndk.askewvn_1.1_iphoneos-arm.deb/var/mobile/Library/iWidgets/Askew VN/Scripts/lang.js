var WeatherIcon = 2; // 1= white, 2= black
var Lang = "vi"; 

if (Lang == "vi") {
    var days = ["Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"];
    var shortdays = ["C.N", "T.2", "T.3", "T.4", "T.5", "T.6", "T.7"];
    var shortmonths=["Tháng 1","Tháng 2","Tháng 3","Tháng 4","Tháng 5","Thắng 6","Tháng 7","Tháng 8","Tháng 9","Tháng 10","Tháng 11","Thgangs 12"];
    var months = ["Thg.1", "Thg.2", "Thg.3", "Thg.4", "Thg.5", "Thg.6", "Thg.7", "Thg.8", "Thg.9", "Thg.10", "Thg.11", "Thg.12"];
    var hourtext = ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
    var weatherdesc = ["Có Lốc tố", "Có Bão nhiệt đới", "Trời Có bão", "Trời Có giông", "Trời Có giông", "Có Tuyết rơi", "Có Mưa đá", "Có Mưa đá", "Có Mưa phùn", "Có Mưa phùn", "Trời lạnh", "Trơi Có mưa", "Trời Có mưa", "Trời Đang mưa", "Trời Có bão", "Có Tuyết rơi", "Có Tuyết rơi", "Có Tuyết rơi", "Có Mưa đá", "Có Mưa đá", "Có Mưa bay", "Sương mù", "Có Sương mù", "Có Sương mù", "Có Gió mạnh", "Trời Có gió", "Trời lạnh", "Trời Nhiều mây", "Trời Nhiều mây", "Trời Nhiều mây", "Trời Nhiều mây", "Trời Nhiều mây", "Trời quang", "Trời đẹp", "Trời trong", "Trời trong", "Có Mưa đá", "Trời nóng", "Có Sấm sét", "Có Sấm sét", "Có Sấm sét", "Có mưa", "Có Tuyết rơi", "Có Tuyết rơi", "Có Tuyết rơi", "Trời Ít mây", "Trời Có giông", "Trời Có giông", "Trời Có giông", "blank"];
} 